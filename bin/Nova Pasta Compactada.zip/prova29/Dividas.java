import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Objects;

public class Dividas extends Conta{

    
    private Double  desconto;
  
                public Dividas () {
                }

                public Dividas (int id, int ano, int mes,Double valor, Double desconto, Pessoas pessoas) {
                    super(id, mes, ano, valor, pessoas);
                    this.desconto = desconto;
                
                }

                public double getPercentualDescontos() {
                    return this.desconto = desconto;
                }

                public void setPercentualDescontos(double percentualdescontos) {
                    this.desconto = desconto;
                }

                          
                Dividas(int mes, int ano, double valor, int idpessoa, double percentual_desconto) {
                    String url = "jdbc:mysql://localhost:3306/contas";
                    String user = "root";
                    String password = "";
                        try {
                        Connection connection = DriverManager.getConnection(url, user, password);
                        String sql = " INSERT INTO dividas (ano, mes, valor, percentual_desconto, pessoas_id) VALUES (?,?,?,?,?)";
            
                        PreparedStatement statemente = connection.prepareStatement(sql);
                        statemente.setInt(1, ano);
                        statemente.setInt(2, mes);
                        statemente.setDouble(3, valor);
                        statemente.setDouble(4, percentual_desconto);
                        statemente.setInt(5, idpessoa);
                       
                        statemente.execute();
                        connection.close();
            
                    } catch (SQLException e) {
                        System.out.println(e);
                    }
}
                }
                

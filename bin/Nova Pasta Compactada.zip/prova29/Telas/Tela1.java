package Telas;


import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

public class Tela1 extends JFrame {
  
    private static final long serialVersionUID = 1L;
    private JButton botao;
    private JTextField textNome;
    private JLabel labelNome;
    private JTextField textEmail;
    private JLabel labelEmail;
    private JTextField textId;
    private JLabel labelId;

    public Tela1(int i, String string, String string2) {
        super("Pessoas");
        botao = new JButton("Cadastra");

        textId = new JTextField(25);
        labelId = new JLabel("Id");

        textNome = new JTextField(25);
        labelNome = new JLabel("Nome");

        textEmail = new JTextField(25);
        labelEmail = new JLabel("Email");


        Container pane = this.getContentPane();
        pane.setLayout(new FlowLayout(FlowLayout.CENTER));

        pane.add(labelId);
        pane.add(textId);

        pane.add(labelNome);
        pane.add(textNome);

        pane.add(labelEmail);
        pane.add(textEmail);

        pane.add(botao);
        this.setVisible(true);
        this.setSize(300, 300);
        this.setContentPane(pane);

        ActionListener handlerAction = new ActionListener() {
            public void actionPerformed(final ActionEvent event) {
                methodAction(event);
            }
        };
      
        botao.addActionListener(handlerAction);
    }

         public Tela1() {
	}

		private void methodAction(final ActionEvent e) {
      
        if (e.getSource() == botao) {
            String nome = textNome.getText();
            String email = textEmail.getText();

                      
        }

    }

		public static JButton getSource() {
			return null;
		}

	
   

}
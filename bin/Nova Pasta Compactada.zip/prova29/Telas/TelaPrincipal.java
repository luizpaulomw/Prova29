package Telas;
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrincipal extends JFrame {
    private JButton botaoPessoa;

    private JButton botaoDivida;
    private JButton botaoProvento;
    private JButton botaoConsultaPessoa;
    private JButton botaoConsultaDivida;
    private JButton botaoConsultaProvento;

    public TelaPrincipal() {
      
        botaoPessoa = new JButton(" Pessoa");
        botaoDivida = new JButton("Divida");
        botaoProvento = new JButton(" Proventos");
        botaoConsultaPessoa = new JButton(" consulta pessoa");
        botaoConsultaDivida = new JButton(" condulta dividas");
        botaoConsultaProvento = new JButton("consulta provento");

        Container pane = this.getContentPane();
        pane.setLayout(new FlowLayout(FlowLayout.CENTER));

        pane.add(botaoPessoa);
        pane.add(botaoDivida);
        pane.add(botaoProvento);
        pane.add(botaoConsultaPessoa);
        pane.add(botaoConsultaDivida);
        pane.add(botaoConsultaProvento);

        this.setVisible(true);
        this.setSize(200, 300);
        this.setContentPane(pane);

        ActionListener handlerAction = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == botaoPessoa) {
                    new Tela1();
                } else if (e.getSource() == botaoProvento) {
                    new Tela2();
                } else if (e.getSource() == botaoDivida) {
                    new Tela3();
                } else if (e.getSource() == botaoConsultaPessoa) {
                    new Tela4(1);
                }
                
            }
        };
       
        botaoPessoa.addActionListener(handlerAction);
        botaoDivida.addActionListener(handlerAction);
        botaoProvento.addActionListener(handlerAction);
        botaoConsultaPessoa.addActionListener(handlerAction);
        botaoConsultaDivida.addActionListener(handlerAction);
        botaoConsultaProvento.addActionListener(handlerAction);
    }

    public static void main(String[] args) {
        TelaPrincipal menu = new TelaPrincipal();
    }

}
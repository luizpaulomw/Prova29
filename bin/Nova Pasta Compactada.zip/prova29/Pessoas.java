import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Objects;

import Telas.Tela1;

public class Pessoas {
   
    
    private static int id;
    private static String nome;
    private String email;

    public Pessoas() {
    }

    public Pessoas(int id) {
        Pessoas.id = id;
    }

    public Pessoas(String nome, String email) {
        Pessoas.nome = nome;
        this.email = email;    
        this.id = id;
        this.nome = nome;
        this.email = email;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Pessoas id(int id) {
        this.id = id;
        return this;
    }

    public Pessoas nome(String nome) {
        this.nome = nome;
        return this;
    }

    public Pessoas email(String email) {
        this.email = email;
        return this;
    }

    Pessoas(int id,String nome, String email){
        String url = "jdbc:mysql://localhost:3306/contas";
            String user = "root";
            String password = "";
                try {
                Connection connection = DriverManager.getConnection(url, user, password);
                String sql = "INSERT INTO pessoas (id,nome,email) VALUES (?,?,?)";
             
                PreparedStatement statemente = connection.prepareStatement(sql);
                statemente.setInt(1, id);
                statemente.setString(2, nome);
                statemente.setString(3, email);
                
              
                statemente.execute();
                connection.close();
    
            } catch (SQLException e) {            
                System.out.println(email);
            }
        }
   public static Connection getConnection() {
		return null;
    }   
} 




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Proventos extends Conta {

    private Double TXimposto;

                    public Proventos() {
                    }

                    public Proventos(int id,int mes,int ano,Double valor, Pessoas pessoa,double taxa_imposto) {
                        super(id,mes,ano,valor,pessoa); 
                        this.TXimposto = TXimposto;
                    }

                    Proventos(int mes, int ano, double valor, Pessoas pessoa, double imposto) {
                        this(0, mes, ano, valor, pessoa, imposto);
                        String url = "jdbc:mysql://localhost:3306/contas";
                        String user = "root";
                        String password = "";
                            try {
                            Connection connection = DriverManager.getConnection(url, user, password);
                            String sql = "INSERT INTO proventos (ano, mes, valor, TXimposto, pessoas_id) VALUES (?,?,?,?,?)";
                            PreparedStatement statemente = connection.prepareStatement(sql);
                            statemente.setInt(1, ano);
                            statemente.setInt(2, mes);
                            statemente.setDouble(3, valor);
                            statemente.setDouble(4, imposto);
                            statemente.setInt(5, pessoa.getId());
                            statemente.execute();
                            connection.close();
                        } catch (SQLException e) {
                            System.out.println(e);
                  }
            }
            
}
